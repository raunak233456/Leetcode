package stack_Queue;

import java.util.LinkedList;
import java.util.Queue;

public class qu {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		dynamicstack stack = new dynamicstack();
		stack.push(23);
		stack.push(25);
		stack.push(26);
		stack.push(25);
		stack.push(20);
		
		System.out.println(stack.pop());
		
		
		 
		
	}

}
