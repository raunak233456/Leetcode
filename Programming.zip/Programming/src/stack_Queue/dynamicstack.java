package stack_Queue;

public class dynamicstack {

	protected int[] data;
	private static final int DEAFULT_SIZE = 3; // static -same for all custom stack , private - dont want people to change it directly,final - dont want to change by myself
	
	 int ptr = -1;
	public dynamicstack(int size) // when size is given
	{
		this.data = new int[size]; 
	}
		// when nothing is passed
	public dynamicstack()
	{
		this(DEAFULT_SIZE);
	}
	
	public boolean push(int item)
	{
		//if(ptr == data.length)
			//return false;
		if(ISFULL())
		{
			int[]temp = new int[data.length*2];
			System.arraycopy(data, 0, temp, 0, data.length);
			data = temp;
		}
			
	    data[++ptr] = item;
		return true;
		}
	
	private boolean ISFULL()// private only accessible within declared class
	{
		
		return ptr == data.length-1;
			
		
		
	}
	public int pop()
	{
		
		if(ISEMPTY())
		{
			System.out.println("IS empty");
		}
		int remove = data[ptr];
		ptr--;
		return remove;
	}
	private boolean ISEMPTY()
	{
		return ptr ==-1;
		
	}

}
