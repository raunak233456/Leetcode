package stack_Queue;

import java.util.Stack;

public class first {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 
		
		Stack<Integer> stack = new Stack<>();
		
		stack.push(23);
		stack.push(24);
		stack.push(25);
		
		System.out.println(stack.pop());
		
	}

}
