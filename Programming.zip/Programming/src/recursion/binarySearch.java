package recursion;

public class binarySearch {
	public static void main(String[] args)
	{
	
	int[] a = {1,2,3,4,4,5,8,6,7};
	int el = 7;
	
 System.out.println(BS(a,el,0,a.length-1));
	
	
}
	
	
	static int BS(int[] a, int el, int l, int r)
	{
		
		if(l>r)
			return -1;
	
	int mid = l+(r-l)/2;
	if(a[mid] == el)
		return mid;
	
	if(a[mid] > el)
	
	return BS(a,el,l,mid-1);
	return BS(a,el,mid+1,r);}
	
		
		
	

}
