package recursion;

public class reverse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	int[] a = {1,2,3,4,5};
 System.out.println(arr(a,0));
		
		
	}
	
	static boolean arr(int[] a, int index)
	{
		if(index == a.length-1)
			return true;
		return a[index] <a[index +1] && arr(a,index+1);
		
	}
	}