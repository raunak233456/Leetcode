package Package2;

public class parse {
	 public static void main(String args[]) {
		 int number = 123;
	      String str = Integer.toString(number);
	      System.out.println(str.length());

	      
	      
	   }
	}


