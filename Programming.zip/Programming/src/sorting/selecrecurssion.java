package sorting;

import java.util.Arrays;

public class selecrecurssion {

	public static void main(String[] args)
	{
		int[] a = {1,5,4,3,6,8,7};
		selec(a , 0);
		System.out.println(Arrays.toString(a));
	}
	static void selec(int[]a, int index)
	{
	  if(index == a.length)
		  return;
			
			int maxel = max(a,0,a.length-1-index);
			swap(a,maxel,a.length-1-index);
			selec(a, index+1);
			
			}
	
	
	static int max(int[]a , int start, int end)
	{ 
		int max = start;
		for(int i = start;i<=end;i++)
		{
			if(a[i] > a[max])
				max = i;
		}
		
		return max;
	}
	
	static void swap(int[]a, int start, int end)
	{
		int temp = a[start];
		a[start] = a[end];
		a[end] = temp;
	}

	
}
