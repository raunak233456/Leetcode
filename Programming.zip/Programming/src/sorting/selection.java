package sorting;

import java.util.Arrays;

public class selection {
	
	public static void main(String[] args)
	{
		int[] a = {1,5,4,3,6,8,7};
		selec(a);
		System.out.println(Arrays.toString(a));
	}
	static void selec(int[] a)
	{
		for(int i =0;i<a.length;i++)
			{
			int start = 0;
			int end = a.length-1-i;
			int maxel = max(a,start,end);
			swap(a,maxel,end);
			
			}
	
	}
	
	static int max(int[]a , int start, int end)
	{ int max = start;
		for(int i = start;i<=end;i++)
		{
			if(a[i] > a[max])
max = i;
		}
		
		return max;
	}
	
	static void swap(int[]a, int start, int end)
	{
		int temp = a[start];
		a[start] = a[end];
		a[end] = temp;
	}

}
