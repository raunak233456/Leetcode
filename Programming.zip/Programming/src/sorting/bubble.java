package sorting;

import java.util.Arrays;

public class bubble {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] a  = {1,4,6,3,2,8,6};
	    bubblesort(a);
       System.out.println(Arrays.toString(a));
       
       recbubble(a,1);
       System.out.println(Arrays.toString(a));
	}
	
	static void bubblesort(int[] a)
	{
		
		for(int i=0;i<a.length;i++)
			
		{
		
			for(int j=1;j<a.length-i;j++)
			{
				if(a[j]<a[j-1])
				{
					int temp = a[j];
					a[j] = a[j-1];
					a[j-1] = temp;
				}
				}	}
	}

	static void recbubble(int[] a, int index)
	{
		if(index == a.length)
			return;
			if(a[index] <a[index-1])
		{
			int temp = a[index];
			a[index] = a[index-1];
			a[index-1] = temp;
		}
		recbubble(a, index+1);
	}
}
