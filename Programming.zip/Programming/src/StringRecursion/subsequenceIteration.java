package StringRecursion;

import java.util.ArrayList;
import java.util.List;

public class subsequenceIteration {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   int[] arr=  {1,2,3};
   ArrayList<ArrayList<Integer>> ans = subseq(arr);
   for(ArrayList<Integer> list : ans)
   {
   
   System.out.println(list);
	}
	}
	static ArrayList<ArrayList<Integer>> subseq(int[] arr)
	{
		
		ArrayList<ArrayList<Integer>> outer = new ArrayList<>();
		
		outer.add(new ArrayList<>());
		for(int num : arr)
		{
		int n = outer.size(); 
		int i ;
		for(i=0 ;i<n;i++);
		{
			ArrayList<Integer> al = new ArrayList<>(outer.get(i));	
			al.add(num);
		    outer.add(al);
					
		}
		
	}
		return outer;
		}

}
