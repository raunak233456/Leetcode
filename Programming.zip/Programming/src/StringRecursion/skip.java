package StringRecursion;

public class skip {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     System.out.println(skip("baccdah"));
	}

	static String skip(String u)
			{
		if(u.isEmpty())
			return "";
		
		char ch = u.charAt(0);
		if(ch == 'a')
			return skip (u.substring(1));
		return ch+skip(u.substring(1));
		
			}
}
