package StringRecursion;

public class subsequence {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 subse("", "abc");
	}
	
	static void subse(String p, String u)
	{
		if(u.isEmpty())
		{
			System.out.println(p);
		return;}
		
		char ch = u.charAt(0);
		subse(ch + p, u.substring(1));
		subse(p,u.substring(1));
		subse(p+(ch+0), u.substring(1));
		
		
	}

}
