package Array;

public class ObjectTest {

	public static void main(String[] args) {
		Object[] array=new Object[3];
		array[0]= 102;
		array[1]= "csharp";
		
		System.out.println(array[1]);
		
       }

}
