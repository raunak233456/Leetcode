package Array;

public class ArrayString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
         String[] s = new String[4];
         
         s[0] = "test";
         
         int leng = s.length;
         for(int i = 0;i<leng;i++)
         {
        	 
         
         System.out.println(s[i]);
         }
}

}
