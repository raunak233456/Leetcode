package Array;

public class Array_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  int[] a = new int [5];
  
  a[0] = 1;
  a[2]= 2;
  
  int len = a.length;
  
  for(int i = 0;i<len;i++)

  {
	  System.out.println(a[i]);
  }
  
	}

}
